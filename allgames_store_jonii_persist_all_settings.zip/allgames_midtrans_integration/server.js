require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const midtransClient = require('midtrans-client');
const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'transactions.json');
const PRODUCTS_FILE = path.join(__dirname, 'products.json');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');

app.use(express.json({ limit: '12mb' }));
// Never serve raw database files through the static-file handler. Read/write them only via API routes.
app.use((req,res,next)=>{ if(['/products.json','/transactions.json','/settings.json','/.env'].includes(req.path)) return res.status(404).json({error:'Not found'}); next(); });
app.use(express.static(__dirname));
const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY || 'SET_SERVER_KEY_IN_ENV',
  clientKey: process.env.MIDTRANS_CLIENT_KEY || ''
});
function readDb(){ try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); } catch { return {}; } }
function writeDb(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
function readProducts(){ try { const v=JSON.parse(fs.readFileSync(PRODUCTS_FILE,'utf8')); return Array.isArray(v)?v:[]; } catch { return []; } }
function writeProducts(items){ const tmp=PRODUCTS_FILE+'.tmp'; fs.writeFileSync(tmp, JSON.stringify(items,null,2)); fs.renameSync(tmp, PRODUCTS_FILE); }
function readSettings(){ try { const v=JSON.parse(fs.readFileSync(SETTINGS_FILE,'utf8')); return {danaNumber:String(v.danaNumber||''),gopayNumber:String(v.gopayNumber||''),danaQR:String(v.danaQR||''),gopayQR:String(v.gopayQR||''),allPayQR:String(v.allPayQR||''),updatedAt:Number(v.updatedAt)||0}; } catch { return {danaNumber:'',gopayNumber:'',danaQR:'',gopayQR:'',allPayQR:'',updatedAt:0}; } }
function writeSettings(settings){ const tmp=SETTINGS_FILE+'.tmp'; fs.writeFileSync(tmp, JSON.stringify(settings,null,2)); fs.renameSync(tmp, SETTINGS_FILE); }
function markProductSold(productId){ if(!productId) return; const items=readProducts(); const i=items.findIndex(p=>String(p.id)===String(productId)); if(i>=0){items[i]={...items[i],stock:'SOLD',soldAt:Date.now(),updatedAt:Date.now()};writeProducts(items);} }
function requireAdmin(req,res){ if(!process.env.ADMIN_API_KEY || req.get('x-admin-key') !== process.env.ADMIN_API_KEY){res.status(401).json({error:'Kunci admin server tidak cocok. Atur ADMIN_API_KEY di hosting.'});return false;} return true; }
app.get('/api/products', (_req,res)=>res.set('Cache-Control','no-store').json(readProducts()));
// Shared payment settings: numbers and QR images persist on the server.
app.get('/api/payment-settings', (_req,res)=>res.set('Cache-Control','no-store').json(readSettings()));
app.put('/api/payment-settings', (req,res)=>{
  if(!requireAdmin(req,res)) return;
  const b=req.body||{};
  for(const f of ['danaQR','gopayQR','allPayQR']){ if(b[f]!==undefined && b[f]!=='' && (typeof b[f]!=='string' || b[f].length>8*1024*1024 || !/^data:image\/(jpeg|png|webp|gif);base64,/.test(b[f]))) return res.status(400).json({error:'Format QR tidak valid atau ukuran terlalu besar.'}); }
  const clean={danaNumber:String(b.danaNumber||'').trim().slice(0,40),gopayNumber:String(b.gopayNumber||'').trim().slice(0,40),danaQR:String(b.danaQR||''),gopayQR:String(b.gopayQR||''),allPayQR:String(b.allPayQR||''),updatedAt:Date.now()};
  writeSettings(clean); res.set('Cache-Control','no-store').json({ok:true,settings:clean});
});
app.post('/api/products', (req,res)=>{
  if(!requireAdmin(req,res)) return;
  const p=req.body||{}; const items=readProducts();
  if(!p.id || !String(p.name||'').trim() || !String(p.category||'').trim() || !Number.isSafeInteger(Number(p.price)) || Number(p.price)<0 || Number(p.price)>50000000) return res.status(400).json({error:'Data produk tidak valid.'});
  if(typeof p.photo==='string' && p.photo.length>8*1024*1024) return res.status(413).json({error:'Foto terlalu besar. Pilih foto yang lebih kecil.'});
  const clean={id:String(p.id).slice(0,100),name:String(p.name).trim().slice(0,180),category:String(p.category).slice(0,80),game:String(p.game||'').slice(0,100),rank:String(p.rank||'').slice(0,100),price:Number(p.price),stock:String(p.stock||'Tersedia').slice(0,40),desc:String(p.desc||'').slice(0,1000),photo:typeof p.photo==='string' && /^data:image\/(jpeg|png|webp|gif);base64,/.test(p.photo)?p.photo:'',createdAt:Number(p.createdAt)||Date.now(),updatedAt:Date.now()};
  const i=items.findIndex(x=>String(x.id)===clean.id); if(i>=0) items[i]=clean; else items.unshift(clean); writeProducts(items); res.json({ok:true,product:clean});
});
app.delete('/api/products/:id', (req,res)=>{ if(!requireAdmin(req,res)) return; const items=readProducts(); const next=items.filter(p=>String(p.id)!==String(req.params.id)); if(next.length===items.length) return res.status(404).json({error:'Produk tidak ditemukan.'}); writeProducts(next); res.json({ok:true}); });
function statusLabel(s){
  if (s === 'settlement' || s === 'capture') return 'Lunas';
  if (s === 'pending') return 'Menunggu pembayaran';
  if (['deny','cancel','expire','failure'].includes(s)) return 'Gagal/Kedaluwarsa';
  if (s === 'refund' || s === 'partial_refund') return 'Refund';
  return s || 'Menunggu pembayaran';
}
app.get('/api/health', (_req,res)=>res.json({ok:true,midtransConfigured:!!process.env.MIDTRANS_SERVER_KEY && process.env.MIDTRANS_SERVER_KEY !== 'SET_SERVER_KEY_IN_ENV'}));
app.post('/api/checkout', async (req,res)=>{
  try {
    if (!process.env.MIDTRANS_SERVER_KEY || process.env.MIDTRANS_SERVER_KEY === 'SET_SERVER_KEY_IN_ENV') return res.status(503).json({error:'Server Key Midtrans belum dipasang di file .env.'});
    const {orderId,buyerName,buyerContact,productId,productName,amount,productRank,note} = req.body || {};
    const total = Number(amount);
    if (!/^AGS-[A-Z0-9-]{5,80}$/.test(String(orderId||'')) || !String(buyerName||'').trim() || !String(buyerContact||'').trim() || !String(productName||'').trim() || !Number.isSafeInteger(total) || total < 1 || total > 50000000) return res.status(400).json({error:'Data pesanan tidak valid.'});
    const db = readDb();
    if (db[orderId]) return res.status(409).json({error:'ID pesanan sudah digunakan. Silakan ulangi checkout.'});
    const tx = { id:orderId, createdAt:Date.now(), expiresAt:Date.now()+60*60*1000, buyerName:String(buyerName).slice(0,80), buyerContact:String(buyerContact).slice(0,30), productId:String(productId||''), productName:String(productName).slice(0,180), productRank:String(productRank||'').slice(0,100), amount:total, method:'Midtrans', status:'Menunggu pembayaran', note:String(note||'').slice(0,300), midtransStatus:'pending' };
    const parameter = {
      transaction_details: { order_id: orderId, gross_amount: total },
      item_details: [{ id:String(productId||'account').slice(0,50), price:total, quantity:1, name:String(productName).slice(0,50) }],
      customer_details: { first_name:tx.buyerName, phone:tx.buyerContact },
      callbacks: { finish: `${process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`}/?payment=finish&order_id=${encodeURIComponent(orderId)}` },
      expiry: { unit: 'minute', duration: 60 }
    };
    const result = await snap.createTransaction(parameter);
    tx.token = result.token; tx.redirect_url = result.redirect_url; tx.updatedAt = Date.now();
    db[orderId] = tx; writeDb(db);
    res.json({order_id:orderId, token:result.token, redirect_url:result.redirect_url, status:tx.status});
  } catch (e) { console.error('create checkout failed:',e.message); res.status(502).json({error:'Midtrans tidak dapat membuat transaksi. Periksa konfigurasi akun dan coba lagi.'}); }
});
app.get('/api/status/:orderId', async (req,res)=>{
  const db = readDb(); const tx = db[req.params.orderId];
  if (!tx) return res.status(404).json({error:'Transaksi tidak ditemukan.'});
  // Use provider status API, not browser-provided claims.
  if (Date.now() >= Number(tx.expiresAt || tx.createdAt + 60*60*1000) && tx.status === 'Menunggu pembayaran') { tx.status='Kedaluwarsa'; tx.midtransStatus='expire'; tx.updatedAt=Date.now(); db[tx.id]=tx; writeDb(db); }
  try {
    if (process.env.MIDTRANS_SERVER_KEY && process.env.MIDTRANS_SERVER_KEY !== 'SET_SERVER_KEY_IN_ENV') {
      const status = await snap.transaction.status(tx.id);
      tx.midtransStatus = status.transaction_status; tx.status = statusLabel(status.transaction_status); tx.updatedAt=Date.now();
      db[tx.id]=tx; writeDb(db);
      if (tx.status === 'Lunas') markProductSold(tx.productId);
    }
  } catch (e) { /* Keep the last verified status when Midtrans is temporarily unavailable. */ }
  res.json({id:tx.id,status:tx.status,updatedAt:tx.updatedAt,productName:tx.productName,amount:tx.amount,method:tx.method});
});
// Manual-payment orders are also stored on the server so admin history is shared across devices.
app.post('/api/transactions', (req,res)=>{
  const b=req.body||{}; const id=String(b.id||''); const amount=Number(b.amount);
  if(!/^AGS-[A-Z0-9-]{5,80}$/.test(id) || !String(b.buyerName||'').trim() || !String(b.buyerContact||'').trim() || !String(b.productName||'').trim() || !Number.isSafeInteger(amount) || amount<1 || amount>50000000) return res.status(400).json({error:'Data pesanan tidak valid.'});
  const db=readDb(); if(db[id]) return res.status(409).json({error:'ID pesanan sudah digunakan.'});
  const tx={id,createdAt:Number(b.createdAt)||Date.now(),updatedAt:Date.now(),expiresAt:Number(b.expiresAt)||Date.now()+60*60*1000,buyerName:String(b.buyerName).slice(0,80),buyerContact:String(b.buyerContact).slice(0,30),productId:String(b.productId||'').slice(0,100),productName:String(b.productName).slice(0,180),productRank:String(b.productRank||'').slice(0,100),amount,method:String(b.method||'Manual').slice(0,40),paymentTarget:String(b.paymentTarget||'').slice(0,180),status:'Menunggu pembayaran',note:String(b.note||'').slice(0,300)};
  db[id]=tx; writeDb(db); res.status(201).json({ok:true,transaction:tx});
});
app.put('/api/admin/transactions/:id', (req,res)=>{
  if(!requireAdmin(req,res)) return;
  const allowed=['Lunas','Dibatalkan','Menunggu pembayaran','Kedaluwarsa','Refund']; const status=String((req.body||{}).status||'');
  if(!allowed.includes(status)) return res.status(400).json({error:'Status transaksi tidak valid.'});
  const db=readDb(); const tx=db[req.params.id]; if(!tx) return res.status(404).json({error:'Transaksi tidak ditemukan.'});
  tx.status=status; tx.updatedAt=Date.now(); db[tx.id]=tx; writeDb(db);
  if(status==='Lunas') markProductSold(tx.productId);
  res.json({ok:true,transaction:tx});
});
app.get('/api/admin/transactions', (req,res)=>{
  if (!process.env.ADMIN_API_KEY || req.get('x-admin-key') !== process.env.ADMIN_API_KEY) return res.status(401).json({error:'Unauthorized'});
  const db=readDb(); res.set('Cache-Control','no-store').json(Object.values(db).sort((a,b)=>b.createdAt-a.createdAt));
});
app.post('/api/midtrans-notification', async (req,res)=>{
  try {
    if (!process.env.MIDTRANS_SERVER_KEY || process.env.MIDTRANS_SERVER_KEY === 'SET_SERVER_KEY_IN_ENV') return res.status(503).end();
    const orderId=String(req.body.order_id||'');
    // Fetch authoritative status directly from Midtrans before changing the transaction.
    const verified=await snap.transaction.status(orderId);
    if (String(verified.order_id)!==orderId) return res.status(400).json({error:'Order ID mismatch'});
    const db=readDb(); const tx=db[orderId];
    if (!tx) return res.status(404).json({error:'Order not found'});
    if (Number(verified.gross_amount)!==Number(tx.amount)) return res.status(400).json({error:'Amount mismatch'});
    tx.midtransStatus=verified.transaction_status; tx.status=statusLabel(verified.transaction_status); tx.updatedAt=Date.now(); tx.paymentType=verified.payment_type||'';
    db[orderId]=tx; writeDb(db); if(tx.status==='Lunas') markProductSold(tx.productId); res.status(200).json({ok:true});
  } catch(e) { console.error('notification verify failed:',e.message); res.status(500).json({error:'Could not verify notification'}); }
});
app.get('/payment-result', (req,res)=>res.redirect('/?payment=finish'));
app.listen(PORT,()=>console.log(`AllGames Store running on http://localhost:${PORT}`));
