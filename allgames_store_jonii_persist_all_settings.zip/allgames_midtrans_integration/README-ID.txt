ALLGAMES STORE JONII — INTEGRASI MIDTRANS SNAP

Isi paket:
- index.html: website AllGames Store dengan pilihan pembayaran Midtrans.
- server.js: backend Node.js untuk pembayaran Midtrans 60 menit, notifikasi status, katalog produk bersama, dan riwayat transaksi.
- settings.json: menyimpan nomor DANA/GoPay dan foto QRIS/QR pembayaran bersama.
- products.json: dibuat otomatis saat admin pertama kali menyimpan produk; berisi detail produk dan foto agar semua pengunjung server yang sama dapat melihatnya.
- Bagian Joki memiliki langkah pengajuan: isi target -> hubungi admin -> tunggu harga disetujui -> baru ikuti instruksi pembayaran resmi.
- transactions.json: dibuat otomatis setelah transaksi pertama; menyimpan riwayat pesanan Midtrans dan pembayaran manual di server.

PENTING
Pembayaran otomatis tidak aktif hanya dengan membuka file HTML. Backend harus dijalankan di server hosting, dan kredensial Midtrans harus diisi. Jangan pernah meletakkan Server Key di HTML/browser atau mengirimkannya lewat chat.

MENJALANKAN LOKAL (MODE SANDBOX/TEST)
1. Instal Node.js versi LTS.
2. Salin .env.example menjadi .env.
3. Isi MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY dari dashboard Midtrans Sandbox. Pastikan MIDTRANS_IS_PRODUCTION=false. Atur ADMIN_API_KEY dengan string acak panjang yang hanya diketahui admin.
4. Di folder ini jalankan: npm install
5. Jalankan: npm start
6. Untuk menyimpan katalog bersama, admin menambah/mengedit produk saat website dibuka dari server; saat diminta masukkan ADMIN_API_KEY yang sama dengan nilai di environment hosting. Foto, harga, deskripsi, dan status stok disimpan di products.json di server, bukan hanya localStorage. Pengunjung lain mengambil katalog dari /api/products. Jika sudah ada katalog di browser admin lama, sinkronkan saat diminta website.
7. Nomor DANA/GoPay dan foto QR DANA/GoPay/QRIS disimpan ke settings.json lewat API server; setelah berhasil disimpan, semua pengunjung membaca pengaturan yang sama.
7. Riwayat transaksi Midtrans dan pembayaran manual disimpan di transactions.json. Saat admin masuk, panel memuat riwayat dari server; perubahan status transaksi juga dikirim ke server. Jika transaksi ditandai lunas, stok akun terkait di katalog bersama ditandai SOLD. Jangan hapus products.json, transactions.json, atau settings.json jika ingin mempertahankan data. Pastikan semua file JSON berada pada disk persisten hosting.
8. File JSON hanya bertahan selama disk hosting bertahan. Pastikan hosting menyediakan disk persisten dan backup; beberapa hosting sementara menghapus file lokal saat redeploy.
9. Semua pesanan menampilkan batas waktu 60 menit. Midtrans Snap diberi expiry 60 menit; pembayaran manual QR/ewallet lama hanya diberi timer dan status kedaluwarsa lokal, bukan verifikasi otomatis.
9. Buka http://localhost:3000 (jangan buka index.html langsung dari file manager).
10. Coba transaksi dengan instruksi dan metode uji yang tersedia di dokumentasi Midtrans Sandbox.

UNTUK STATUS OTOMATIS DAN LIVE
1. Deploy folder ini ke hosting yang mendukung Node.js dan HTTPS.
2. Atur environment variables dari dashboard hosting; jangan unggah file .env ke publik.
3. Atur PUBLIC_BASE_URL menjadi URL HTTPS situs yang sudah dipasang.
4. Pada Dashboard Midtrans, atur Payment Notification URL ke https://DOMAIN-KAMU/api/midtrans-notification.
5. Uji status pending, settlement/capture, expire, dan cancel pada Sandbox sebelum mengaktifkan Production.
6. Setelah verifikasi, pindahkan ke kredensial Production dan MIDTRANS_IS_PRODUCTION=true.

CATATAN KEAMANAN DAN KETERBATASAN
- Endpoint /api/admin/transactions dan perubahan status transaksi dilindungi ADMIN_API_KEY. Data transaksi baru yang dibuat melalui website tersimpan di server; data transaksi lama yang hanya ada di localStorage browser belum otomatis dipindahkan ke transactions.json.
- Katalog produk kini disimpan di products.json di server dan dibagikan ke semua pengunjung pada instance server yang sama. Untuk produksi berskala ramai/multi-instance, pindahkan data ke database persisten dan foto ke object storage. Saat ini jumlah yang dikirim frontend divalidasi, tetapi harga perlu diverifikasi terhadap katalog server agar tidak bisa dimanipulasi; jangan gunakan untuk penjualan live bernilai nyata sebelum hal ini dan autentikasi admin diselesaikan.
- File transactions.json cocok hanya untuk uji awal/satu instance; produksi sebaiknya memakai database persisten.
- Webhook melakukan pengecekan status langsung ke API Midtrans sebelum mengubah status. Jangan menandai pesanan lunas hanya dari redirect browser.
- QRIS/metode pembayaran yang muncul ditentukan oleh channel yang aktif di akun Midtrans.
